#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct User {
    char username[50];
    char password[50];
};

const int MAX_USERS = 10;
const int MAX_CART_ITEMS = 10;

void createUserAccount(FILE *file, struct User users[], int *numUsers);
int login(FILE *file, struct User users[], int numUsers);
void displayItems();
void addToCart(float cart[], int *itemCount);
float calculateTotal(float cart[], int itemCount);

int main() {
    printf("\n--- Welcome to the Online Grocery Store ---\n");

    FILE *file = fopen("users.txt", "a+");
    if (file == NULL) {
        printf("Error opening file");
        return 1;
    }

    struct User users[MAX_USERS];
    int numUsers = 0;

    // Read existing user data from file
    while (fscanf(file, "%s %s\n", users[numUsers].username, users[numUsers].password) == 2) {
        numUsers++;
        if (numUsers >= MAX_USERS) break;
    }

    int choice;
    do {
        printf("\nChoose an option:\n");
        printf("1. Login\n");
        printf("2. Create Account\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                if (numUsers == 0) {
                    printf("No users exist. Please create an account first.\n");
                } else {
                    int loginStatus = login(file, users, numUsers);
                    if (loginStatus == 1) {
                        printf("\n------------------------------------------\n");
                        printf("   Login successful! Welcome to the store!\n");
                        printf("------------------------------------------\n");

                        float *cart = malloc(MAX_CART_ITEMS * sizeof(float));
                        int itemCount = 0;

                        displayItems();
                        addToCart(cart, &itemCount);

                        float totalAmount = calculateTotal(cart, itemCount);
                        printf("Total Amount: Rs%.2f\n", totalAmount);

                        free(cart);
                        printf("Thank you for shopping with us!\n");
                        printf("----------------------------\n");
                        return 0; 
                    } else {
                        printf("\n--------------------------------------\n");
                        printf("   Login failed. Incorrect credentials.\n");
                        printf("--------------------------------------\n");
                    }
                }
                break;
            case 2:
                createUserAccount(file, users, &numUsers);
                break;
            case 3:
                printf("Thank you for visiting. Goodbye!\n");
                fclose(file);
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while (1);

    fclose(file);
    return 0;
}

void createUserAccount(FILE *file, struct User users[], int *numUsers) {
    if (*numUsers >= MAX_USERS) {
        printf("Maximum number of users reached. Cannot create a new account.\n");
        return;
    }

    printf("\n--- Create a New Account ---\n");

    struct User newUser;
    printf("Enter username: ");
    scanf("%s", newUser.username);

    printf("Enter password: ");
    scanf("%s", newUser.password);

    fprintf(file, "%s %s\n", newUser.username, newUser.password);
    strcpy(users[*numUsers].username, newUser.username);
    strcpy(users[*numUsers].password, newUser.password);
    (*numUsers)++;
    printf("Account created successfully!\n");
}

int login(FILE *file, struct User users[], int numUsers) {
    char username[50];
    char password[50];

    printf("\n--- Login ---\n");

    printf("Enter username: ");
    scanf("%s", username);

    printf("Enter password: ");
    scanf("%s", password);

    for (int i = 0; i < numUsers; i++) {
        if (strcmp(username, users[i].username) == 0 && strcmp(password, users[i].password) == 0) {
            return 1; 
        }
    }

    return 0; 
}

void displayItems() {
    printf("\nItems Available:\n");
    printf("1. Milk - Rs60.00\n");
    printf("2. Bread - Rs40.00\n");
    printf("3. Cheese - Rs80.00\n");
    printf("4. Apple - Rs12.00\n");
    printf("5. Banana - Rs8.00\n");
}

void addToCart(float cart[], int *itemCount) {
    int choice, quantity;
    do {
        printf("Enter item number to add to cart (0 to checkout): ");
        scanf("%d", &choice);

        float price = 0.0;
        switch (choice) {
            case 1:
                price = 60.00;
                break;
            case 2:
                price = 40.00;
                break;
            case 3:
                price = 80.00;
                break;
            case 4:
                price = 12.00;
                break;
            case 5:
                price = 8.00;
                break;
            default:
                price = 0.00;
                break;
        }

        if (price > 0.00 && *itemCount < MAX_CART_ITEMS) {
            printf("Enter quantity for this item: ");
            scanf("%d", &quantity);

            if (quantity > 0) {
                cart[*itemCount] = price * quantity;
                (*itemCount)++;
                printf("Item(s) added to cart.\n");
            } else {
                printf("Invalid quantity. Please enter a positive number.\n");
            }
        } else if (choice != 0) {
            printf("Invalid item number or cart full.\n");
        }
    } while (choice != 0 && *itemCount < MAX_CART_ITEMS);
}

float calculateTotal(float cart[], int itemCount) {
    float total = 0.0;
    for (int i = 0; i < itemCount; i++) {
        total += cart[i];
    }
    return total;
}



