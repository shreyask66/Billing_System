#include <stdio.h>
#include <string.h>

struct User {
    char username[50];
    char password[50];
};

const int MAX_USERS = 10;
const int MAX_USERNAME_LENGTH = 50;
const int MAX_PASSWORD_LENGTH = 50;
const int MAX_CART_ITEMS = 10;

void createUserAccount(struct User users[], int *numUsers);
int login(struct User users[], int numUsers);
void displayItems();
void addToCart(float cart[], int *itemCount);
float calculateTotal(float cart[], int itemCount);

int main() {
    printf("\n--- Welcome to the Online Grocery Store ---\n");

    struct User users[MAX_USERS];
    int numUsers = 0;

    int choice;
    do {
        printf("\nChoose an option:\n");
        printf("1. Login\n");
        printf("2. Create Account\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                // Login
                if (numUsers == 0) {
                    printf("No users exist. Please create an account first.\n");
                } else {
                    int loginStatus = login(users, numUsers);
                    if (loginStatus == 1) {
                        printf("\n------------------------------------------\n");
                        printf("   Login successful! Welcome to the store!\n");
                        printf("------------------------------------------\n");

                        float cart[MAX_CART_ITEMS];
                        int itemCount = 0;

                        displayItems();
                        addToCart(cart, &itemCount);

                        float totalAmount = calculateTotal(cart, itemCount);
                        printf("Total Amount: Rs%.2f\n", totalAmount);

                        printf("Thank you for shopping with us!\n");
                        printf("----------------------------\n");
                        return 0; // Exit the program after successful login
                    } else {
                        printf("\n--------------------------------------\n");
                        printf("   Login failed. Incorrect credentials.\n");
                        printf("--------------------------------------\n");
                    }
                }
                break;
            case 2:
                createUserAccount(users, &numUsers);
                break;
            case 3:
                printf("Thank you for visiting. Goodbye!\n");
                return 0; // Exit the program
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while (1);

    return 0;
}

void createUserAccount(struct User users[], int *numUsers) {
    if (*numUsers >= MAX_USERS) {
        printf("Maximum number of users reached. Cannot create a new account.\n");
        return;
    }

    printf("\n--- Create a New Account ---\n");

    printf("Enter username: ");
    scanf("%s", users[*numUsers].username);

    printf("Enter password: ");
    scanf("%s", users[*numUsers].password);

    (*numUsers)++;
    printf("Account created successfully!\n");
}

int login(struct User users[], int numUsers) {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];

    printf("\n--- Login ---\n");

    printf("Enter username: ");
    scanf("%s", username);

    printf("Enter password: ");
    scanf("%s", password);

    for (int i = 0; i < numUsers; i++) {
        if (strcmp(username, users[i].username) == 0 && strcmp(password, users[i].password) == 0) {
            return 1; // Successful login
        }
    }

    return 0; // Login failed
}

void displayItems() {
    printf("\nItems Available:\n");
    printf("1. Milk - Rs60.00\n");
    printf("2. Bread - Rs40.00\n");
    printf("3. Cheese - Rs80.00\n");
    printf("4. Apple - Rs12.00\n");
    printf("5. Banana - Rs8.00\n");
}

void addToCart(float cart[], int *itemCount) {
    int choice, quantity;
    do {
        printf("Enter item number to add to cart (0 to checkout): ");
        scanf("%d", &choice);

        float price = 0.0;
        switch (choice) {
            case 1:
                price = 60.00;
                break;
            case 2:
                price = 40.00;
                break;
            case 3:
                price = 80.00;
                break;
            case 4:
                price = 12.00;
                break;
            case 5:
                price = 8.00;
                break;
            default:
                price = 0.00;
                break;
        }

        if (price > 0.00 && *itemCount < MAX_CART_ITEMS) {
            printf("Enter quantity for this item: ");
            scanf("%d", &quantity);

            if (quantity > 0) {
                cart[*itemCount] = price * quantity;
                (*itemCount)++;
                printf("Item(s) added to cart.\n");
            } else {
                printf("Invalid quantity. Please enter a positive number.\n");
            }
        } else if (choice != 0) {
            printf("Invalid item number or cart full.\n");
        }
    } while (choice != 0 && *itemCount < MAX_CART_ITEMS);
}

float calculateTotal(float cart[], int itemCount) {
    float total = 0.0;
    for (int i = 0; i < itemCount; i++) {
        total += cart[i];
    }
    return total;
}
